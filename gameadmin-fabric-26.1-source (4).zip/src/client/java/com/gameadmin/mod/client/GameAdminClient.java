package com.gameadmin.mod.client;

import com.gameadmin.mod.CastRequestPayload;
import com.gameadmin.mod.FeedbackPayload;
import com.gameadmin.mod.FlightStatePayload;
import com.gameadmin.mod.FlightTogglePayload;
import com.gameadmin.mod.GameAdminMod;
import com.gameadmin.mod.Payloads;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.CommandBlock;
import org.lwjgl.glfw.GLFW;

/** Client entrypoint: keys, the VFX overlay and the receivers. */
public class GameAdminClient implements ClientModInitializer {
    private static KeyMapping openKey;
    private static KeyMapping repeatKey;
    private static KeyMapping flyKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(GameAdminMod.id("main"));

        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.gameadmin.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, category));
        repeatKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.gameadmin.repeat", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, category));
        flyKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.gameadmin.fly", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.consumeClick()) {
                if (client.player != null) {
                    client.setScreen(new AdminScreen());
                }
            }
            while (repeatKey.consumeClick()) {
                if (client.player != null && ClientState.lastCast >= 0) {
                    ClientPlayNetworking.send(new CastRequestPayload(ClientState.lastCast));
                }
            }
            while (flyKey.consumeClick()) {
                if (client.player != null) {
                    ClientPlayNetworking.send(new FlightTogglePayload(!ClientState.flightOn));
                }
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(FeedbackPayload.TYPE,
                (payload, context) -> ClientState.onFeedback(payload));
        ClientPlayNetworking.registerGlobalReceiver(FlightStatePayload.TYPE,
                (payload, context) -> ClientState.onFlight(payload.on()));

        ClientPlayNetworking.registerGlobalReceiver(Payloads.PassiveState.TYPE,
                (payload, context) -> ClientState.passiveMask = payload.mask());
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Adapt.TYPE, (payload, context) -> {
            ClientState.adaptMob = payload.mob();
            ClientState.adaptLevel = payload.level();
        });
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Notice.TYPE,
                (payload, context) -> Vfx.toast(payload.text(), payload.rgb()));

        // Survival command blocks: right-click one (not sneaking, not in creative) to open our own editor.
        UseBlockCallback.EVENT.register((player, level, hand, hitResult) -> {
            if (!(player instanceof LocalPlayer)) return InteractionResult.PASS;   // ignore the integrated server thread
            if (player.isCreative() || player.isShiftKeyDown() || hand != InteractionHand.MAIN_HAND) {
                return InteractionResult.PASS;
            }
            BlockPos pos = hitResult.getBlockPos();
            if (!(level.getBlockState(pos).getBlock() instanceof CommandBlock)) return InteractionResult.PASS;
            Minecraft.getInstance().setScreen(new CommandBlockScreen(pos));
            return InteractionResult.SUCCESS;
        });

        // Screen VFX and the flight look are drawn on the HUD, just before the chat layer.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, GameAdminMod.id("vfx"), Vfx::extract);
    }
}

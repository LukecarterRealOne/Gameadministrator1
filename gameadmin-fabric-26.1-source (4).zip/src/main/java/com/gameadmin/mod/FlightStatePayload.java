package com.gameadmin.mod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: flight is now on or off (drives the custom flight HUD). */
public record FlightStatePayload(boolean on) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<FlightStatePayload> TYPE =
            new CustomPacketPayload.Type<>(GameAdminMod.id("flight_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FlightStatePayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, FlightStatePayload::on, FlightStatePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}

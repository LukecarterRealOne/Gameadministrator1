package com.gameadmin.mod;

import net.minecraft.server.MinecraftServer;

import java.util.Locale;
import java.util.UUID;

/**
 * Server-side visual effects that EVERY nearby player can see. No particles are used.
 *
 * Each effect is a handful of glowing block display entities that are summoned, animated by interpolating their
 * size/position, and removed again a moment later. Everything is done with vanilla commands, run as the server.
 * "at" is always the UUID of the entity (player or mob) the effect is centred on.
 */
public final class WorldVfx {
    private WorldVfx() {}

    private static int counter = 0;

    /** One size and position of a block display: scale in blocks, translation relative to the anchor. */
    private record Xf(double sx, double sy, double sz, double tx, double ty, double tz) {
        String snbt() {
            return String.format(Locale.ROOT,
                    "{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                            + "translation:[%.3ff,%.3ff,%.3ff],scale:[%.3ff,%.3ff,%.3ff]}",
                    tx, ty, tz, sx, sy, sz);
        }
    }

    // ------------------------------------------------------------------ primitives

    /** Summon one block display at the anchor, then animate it from one shape to another and remove it later. */
    private static void anim(MinecraftServer s, UUID at, String pos, String block, Xf from, Xf to, int ticks, int lifeTicks) {
        int id = ++counter;
        String tag = "gameadmin_fx_" + id;
        String nbt = "{Tags:[\"gameadmin_vfx\",\"" + tag + "\"],"
                + "block_state:{Name:\"minecraft:" + block + "\"},"
                + "brightness:{sky:15,block:15},view_range:3.0f,"
                + "transformation:" + from.snbt() + "}";
        run(s, "execute as " + at + " at @s run summon minecraft:block_display " + pos + " " + nbt);

        // give clients a moment to receive the starting shape, then interpolate to the end shape
        Scheduler.after(100, () -> run(s, "data merge entity @e[tag=" + tag + ",limit=1] "
                + "{start_interpolation:0,interpolation_duration:" + ticks + ",transformation:" + to.snbt() + "}"));
        Scheduler.after(Math.max(ticks, lifeTicks) * 50L + 500L, () -> run(s, "kill @e[tag=" + tag + "]"));
    }

    public static void sound(MinecraftServer s, UUID at, String sound, float volume, float pitch) {
        run(s, String.format(Locale.ROOT, "execute as %s at @s run playsound %s master @a ~ ~ ~ %.2f %.2f",
                at, sound, volume, pitch));
    }

    // ------------------------------------------------------------------ shapes

    /** A flat square ring lying on the ground that grows (or shrinks) from radius r0 to r1. */
    public static void ring(MinecraftServer s, UUID at, String block, double r0, double r1, double y, int ticks) {
        double h = 0.25;
        double t0 = Math.max(0.15, r0 * 0.12), t1 = Math.max(0.15, r1 * 0.06);
        String pos = "~ ~ ~";
        // north and south bars
        anim(s, at, pos, block, new Xf(2 * r0, h, t0, -r0, y, -r0), new Xf(2 * r1, h, t1, -r1, y, -r1), ticks, ticks);
        anim(s, at, pos, block, new Xf(2 * r0, h, t0, -r0, y, r0 - t0), new Xf(2 * r1, h, t1, -r1, y, r1 - t1), ticks, ticks);
        // west and east bars
        anim(s, at, pos, block, new Xf(t0, h, 2 * r0 - 2 * t0, -r0, y, -r0 + t0),
                new Xf(t1, h, 2 * r1 - 2 * t1, -r1, y, -r1 + t1), ticks, ticks);
        anim(s, at, pos, block, new Xf(t0, h, 2 * r0 - 2 * t0, r0 - t0, y, -r0 + t0),
                new Xf(t1, h, 2 * r1 - 2 * t1, r1 - t1, y, -r1 + t1), ticks, ticks);
    }

    /** A column standing on the anchor's feet that changes from w0 x h0 to w1 x h1. */
    public static void column(MinecraftServer s, UUID at, String block, double w0, double h0, double w1, double h1,
                              int ticks, int lifeTicks) {
        anim(s, at, "~ ~ ~", block, new Xf(w0, h0, w0, -w0 / 2, 0.0, -w0 / 2),
                new Xf(w1, h1, w1, -w1 / 2, 0.0, -w1 / 2), ticks, lifeTicks);
    }

    /** A column that starts at full size and thins out to nothing, like a beam from the sky. */
    public static void beam(MinecraftServer s, UUID at, String block, double width, double height, int ticks) {
        column(s, at, block, width, height, 0.04, height, ticks, ticks);
    }

    /** A cube of glass centred on the anchor's body that grows from size0 to size1 and stays for lifeTicks. */
    public static void shell(MinecraftServer s, UUID at, String block, double size0, double size1, int ticks, int lifeTicks) {
        anim(s, at, "~ ~ ~", block,
                new Xf(size0, size0, size0, -size0 / 2, -size0 / 2 + 0.9, -size0 / 2),
                new Xf(size1, size1, size1, -size1 / 2, -size1 / 2 + 0.9, -size1 / 2), ticks, lifeTicks);
    }

    /** A slab floating above the anchor. */
    public static void cloud(MinecraftServer s, UUID at, String block, double size, double height, int ticks, int lifeTicks) {
        anim(s, at, "~ ~ ~", block,
                new Xf(0.1, 0.4, 0.1, -0.05, height, -0.05),
                new Xf(size, 0.8, size, -size / 2, height, -size / 2), ticks, lifeTicks);
    }

    /** A thin streak that falls from a height down to the ground at an offset from the anchor. */
    public static void streak(MinecraftServer s, UUID at, String block, double dx, double dz, double height, int ticks) {
        String pos = String.format(Locale.ROOT, "~%.2f ~ ~%.2f", dx, dz);
        anim(s, at, pos, block, new Xf(0.08, 0.2, 0.08, -0.04, height, -0.04),
                new Xf(0.08, height, 0.08, -0.04, 0.0, -0.04), ticks, ticks);
    }

    /** Removes any effect entities left over from a crash or a stopped server. */
    public static void cleanup(MinecraftServer s) {
        run(s, "kill @e[type=minecraft:block_display,tag=gameadmin_vfx]");
    }

    private static void run(MinecraftServer s, String command) {
        try {
            s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), command);
        } catch (Exception ex) {
            GameAdminMod.LOGGER.warn("VFX command failed: {}", command, ex);
        }
    }
}

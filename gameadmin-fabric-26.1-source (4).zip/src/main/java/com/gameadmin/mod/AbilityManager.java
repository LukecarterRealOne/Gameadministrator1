package com.gameadmin.mod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Server side brain: cooldowns + what every ability does, plus the world-visible VFX (see WorldVfx) and sounds.
 * Anything awkward to do through raw game code (weather, time, effects, lightning) is run as a vanilla command
 * with the server's own permissions, which keeps the mod small and stable across Minecraft versions.
 */
public final class AbilityManager {
    private AbilityManager() {}

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static boolean nextIsNight = true;
    private static int weatherStep = 0;

    public static void handleCast(ServerPlayer player, int id) {
        if (id < 0 || id >= Ability.ALL.length) return;
        Ability ability = Ability.ALL[id];

        long now = System.currentTimeMillis();
        long[] ready = READY_AT.computeIfAbsent(player.getUUID(), k -> new long[Ability.ALL.length]);
        if (now < ready[id]) {
            send(player, id, FeedbackPayload.COOLDOWN, (int) (ready[id] - now));
            return;
        }

        if (!(player.level() instanceof ServerLevel level)) return;
        MinecraftServer server = level.getServer();
        if (!Gate.allowed(player, server)) {
            Gate.deny(player);
            return;
        }

        int affected = 0;
        try {
            affected = switch (ability) {
                case SMITE -> smite(player, level, server);
                case BLINK -> blink(player, level, server);
                case TIME_WARP -> timeWarp(player, server);
                case WEATHER -> weather(player, server);
                case RESTORE -> restore(player, server);
                case GOD_MODE -> godMode(player, server);
                case SKYWARD -> skyward(player, server);
                case FREEZE -> freeze(player, level, server);
                case PURGE -> purge(player, level, server);
                case TIME_STOP -> timeStop(player, server);
                case SEND_NETHER -> sendToDimension(player, level, server, "minecraft:the_nether");
                case SEND_END -> sendToDimension(player, level, server, "minecraft:the_end");
                case SEND_OVERWORLD -> sendToDimension(player, level, server, "minecraft:overworld");
                case OVERDRIVE -> overdrive(player, server);
                case OMNISCIENCE -> omniscience(player, level, server);
                case ZERO_G -> zeroG(player, level, server);
            };
        } catch (Exception ex) {
            GameAdminMod.LOGGER.warn("Ability {} failed", ability, ex);
        }

        ready[id] = now + ability.cooldownMs;
        send(player, id, FeedbackPayload.CAST, affected);
    }

    private static void send(ServerPlayer player, int ability, int status, int value) {
        ServerPlayNetworking.send(player, new FeedbackPayload(ability, status, value));
    }

    // ------------------------------------------------------------------ abilities

    private static int smite(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        UUID me = player.getUUID();
        WorldVfx.sound(server, me, "minecraft:entity.lightning_bolt.thunder", 1.6f, 0.9f);
        int strikes = 0;
        for (LivingEntity e : hostiles(player, level, 28.0)) {
            if (e.distanceTo(player) < 3.5f) continue; // never zap yourself
            if (strikes >= 14) break;
            runAt(server, e, "summon minecraft:lightning_bolt ~ ~ ~");
            if (strikes < 10) {
                UUID t = e.getUUID();
                WorldVfx.beam(server, t, "white_concrete", 0.7, 45, 8);
                WorldVfx.ring(server, t, "yellow_stained_glass", 0.5, 5.0, 0.05, 8);
            }
            strikes++;
        }
        if (strikes == 0) {
            double[] p = rayEnd(player, level, 48.0);
            double dx = p[0] - player.getX(), dz = p[2] - player.getZ();
            if (dx * dx + dz * dz > 16.0) {
                run(server, "summon minecraft:lightning_bolt " + xyz(p[0], p[1], p[2]));
                strikes = 1;
            }
            WorldVfx.ring(server, me, "light_blue_stained_glass", 0.5, 6.0, 0.05, 8);
        }
        return strikes;
    }

    private static int blink(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        UUID me = player.getUUID();
        WorldVfx.column(server, me, "cyan_stained_glass", 1.6, 2.4, 0.1, 3.4, 8, 8);
        WorldVfx.ring(server, me, "light_blue_stained_glass", 2.5, 0.5, 0.05, 8);
        WorldVfx.sound(server, me, "minecraft:entity.enderman.teleport", 1.0f, 1.0f);

        double[] p = rayEnd(player, level, 40.0);
        run(server, "tp " + me + " " + xyz(p[0], p[1], p[2]));

        // arrival burst at the new spot (the anchor is the player, so it follows them there)
        Scheduler.after(150, () -> {
            WorldVfx.column(server, me, "cyan_stained_glass", 0.2, 0.2, 1.8, 3.0, 6, 6);
            WorldVfx.ring(server, me, "light_blue_stained_glass", 0.5, 3.5, 0.05, 8);
            WorldVfx.sound(server, me, "minecraft:entity.enderman.teleport", 1.0f, 1.3f);
        });
        return 1;
    }

    private static int timeWarp(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        boolean toNight = nextIsNight;
        String block = toNight ? "purple_stained_glass" : "yellow_stained_glass";
        run(server, toNight ? "time set night" : "time set day");
        nextIsNight = !nextIsNight;

        WorldVfx.ring(server, me, block, 0.5, 12.0, 0.05, 14);
        Scheduler.after(250, () -> WorldVfx.ring(server, me, block, 0.5, 9.0, 0.05, 12));
        WorldVfx.column(server, me, block, 1.2, 0.1, 0.5, 6.0, 12, 12);
        WorldVfx.sound(server, me, "minecraft:block.bell.use", 1.5f, toNight ? 0.6f : 1.2f);
        return 1;
    }

    private static int weather(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        String[] steps = {"clear", "rain", "thunder"};
        weatherStep = (weatherStep + 1) % steps.length;
        run(server, "weather " + steps[weatherStep]);

        String cloud = switch (weatherStep) {
            case 0 -> "white_stained_glass";
            case 1 -> "light_gray_stained_glass";
            default -> "gray_stained_glass";
        };
        WorldVfx.cloud(server, me, cloud, 12.0, 14.0, 12, 60);
        if (weatherStep == 0) {
            WorldVfx.ring(server, me, "yellow_stained_glass", 0.5, 8.0, 0.05, 12);
        } else {
            for (int i = 0; i < 8; i++) {
                double ang = i * Math.PI / 4.0;
                WorldVfx.streak(server, me, "light_blue_stained_glass",
                        Math.cos(ang) * 4.5, Math.sin(ang) * 4.5, 14.0, 10 + (i % 3) * 3);
            }
        }
        WorldVfx.sound(server, me, weatherStep == 2
                ? "minecraft:entity.lightning_bolt.thunder" : "minecraft:block.beacon.activate", 1.0f, 1.0f);
        return weatherStep;
    }

    private static int restore(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        player.setHealth(player.getMaxHealth());
        String u = me.toString();
        run(server, "effect give " + u + " minecraft:saturation 2 20 true");
        run(server, "effect give " + u + " minecraft:fire_resistance 5 0 true");
        for (String bad : new String[]{"poison", "wither", "hunger", "weakness", "slowness", "nausea",
                "blindness", "mining_fatigue", "darkness", "levitation"}) {
            run(server, "effect clear " + u + " minecraft:" + bad);
        }
        WorldVfx.column(server, me, "lime_stained_glass", 0.5, 0.2, 1.8, 3.2, 14, 10);
        WorldVfx.ring(server, me, "lime_stained_glass", 0.5, 4.0, 0.05, 10);
        WorldVfx.sound(server, me, "minecraft:entity.player.levelup", 1.2f, 1.0f);
        return 1;
    }

    private static int godMode(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        String u = me.toString();
        run(server, "effect give " + u + " minecraft:resistance 20 4 true");
        run(server, "effect give " + u + " minecraft:regeneration 20 2 true");
        run(server, "effect give " + u + " minecraft:absorption 20 4 true");
        run(server, "effect give " + u + " minecraft:fire_resistance 20 0 true");

        WorldVfx.shell(server, me, "yellow_stained_glass", 1.0, 3.4, 8, 12);
        WorldVfx.sound(server, me, "minecraft:block.beacon.activate", 1.5f, 1.0f);
        // a golden pulse at their feet every 2 seconds for the full 20 seconds
        for (int i = 0; i < 10; i++) {
            Scheduler.after(i * 2000L, () -> WorldVfx.ring(server, me, "yellow_stained_glass", 0.8, 3.4, 0.05, 14));
        }
        return 1;
    }

    private static int skyward(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        String u = me.toString();
        WorldVfx.beam(server, me, "cyan_stained_glass", 1.8, 80.0, 14);
        WorldVfx.ring(server, me, "white_stained_glass", 0.5, 5.0, 0.05, 10);
        WorldVfx.sound(server, me, "minecraft:entity.firework_rocket.launch", 1.5f, 0.8f);
        run(server, "effect give " + u + " minecraft:levitation 2 20 true");
        run(server, "effect give " + u + " minecraft:slow_falling 30 0 true");
        return 1;
    }

    private static int freeze(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        UUID me = player.getUUID();
        int count = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(24.0))) {
            if (e == player || e instanceof Player) continue;
            runAs(server, e, "effect give @s minecraft:slowness 10 10 true");
            runAs(server, e, "effect give @s minecraft:weakness 10 3 true");
            runAs(server, e, "effect give @s minecraft:glowing 10 0 true");
            if (count < 12) {
                // an ice block around each frozen mob, for the whole freeze
                WorldVfx.shell(server, e.getUUID(), "light_blue_stained_glass", 0.8, 1.8, 6, 200);
            }
            count++;
        }
        WorldVfx.ring(server, me, "light_blue_stained_glass", 1.0, 24.0, 0.05, 14);
        WorldVfx.sound(server, me, "minecraft:entity.player.hurt_freeze", 1.4f, 0.8f);
        Scheduler.after(10_000, () -> WorldVfx.sound(server, me, "minecraft:block.glass.break", 1.5f, 0.8f));
        return count;
    }

    private static int purge(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        UUID me = player.getUUID();
        int count = 0;
        for (LivingEntity e : hostiles(player, level, 48.0)) {
            if (e.getType() == EntityType.ENDER_DRAGON || e.getType() == EntityType.WITHER) continue; // spare bosses
            if (count < 12) {
                WorldVfx.beam(server, e.getUUID(), "red_concrete", 0.8, 30.0, 8);   // while it still exists
            }
            e.discard();
            count++;
        }
        WorldVfx.ring(server, me, "red_stained_glass", 1.0, 40.0, 0.05, 14);
        Scheduler.after(200, () -> WorldVfx.ring(server, me, "red_stained_glass", 1.0, 30.0, 0.05, 12));
        WorldVfx.sound(server, me, "minecraft:entity.generic.explode", 1.4f, 0.6f);
        WorldVfx.sound(server, me, "minecraft:entity.wither.break_block", 1.2f, 0.8f);
        return count;
    }

    private static int timeStop(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        // Show the bubble first. While the world is frozen the effect entities cannot animate,
        // so the freeze starts after the bubble has finished growing.
        WorldVfx.shell(server, me, "white_stained_glass", 1.0, 16.0, 10, 160);
        WorldVfx.ring(server, me, "light_blue_stained_glass", 0.5, 14.0, 0.05, 12);
        WorldVfx.sound(server, me, "minecraft:block.beacon.deactivate", 1.5f, 0.6f);

        Scheduler.after(800, () -> run(server, "tick freeze"));
        // Always thaw the world again, no matter what happens.
        Scheduler.after(8_000, () -> {
            run(server, "tick unfreeze");
            WorldVfx.sound(server, me, "minecraft:block.beacon.activate", 1.5f, 1.0f);
        });
        return 8;
    }

    /**
     * Sends other players (64 blocks) and hostile mobs (24 blocks) to a dimension.
     * If nobody else is around, the caster goes instead. Returns how many were sent, or -1 for "you".
     */
    private static int sendToDimension(ServerPlayer player, ServerLevel level, MinecraftServer server, String dimension) {
        List<Entity> targets = new ArrayList<>();
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other != player && other.level() == level && other.distanceTo(player) <= 64f) {
                targets.add(other);
            }
        }
        targets.addAll(hostiles(player, level, 24.0));

        boolean self = targets.isEmpty();
        if (self) targets.add(player);

        String color = switch (dimension) {
            case "minecraft:the_nether" -> "orange_stained_glass";
            case "minecraft:the_end" -> "purple_stained_glass";
            default -> "lime_stained_glass";
        };

        boolean fromNether = level.dimension() == Level.NETHER;
        int vfx = 0;
        for (Entity e : targets) {
            UUID id = e.getUUID();
            if (vfx++ < 12) {
                WorldVfx.column(server, id, color, 1.6, 3.2, 0.1, 4.5, 8, 8);
                WorldVfx.ring(server, id, color, 2.5, 0.5, 0.05, 8);
                WorldVfx.sound(server, id, "minecraft:block.portal.travel", 0.5f, 1.2f);
                // arrival effect, once they have landed in the new dimension
                Scheduler.after(300, () -> {
                    WorldVfx.ring(server, id, color, 0.5, 4.0, 0.05, 10);
                    WorldVfx.column(server, id, color, 0.2, 0.2, 1.6, 3.4, 6, 6);
                });
            }

            double x = e.getX(), z = e.getZ();
            double tx, tz;
            switch (dimension) {
                case "minecraft:the_nether" -> {
                    tx = fromNether ? x : x / 8.0;
                    tz = fromNether ? z : z / 8.0;
                }
                case "minecraft:the_end" -> {
                    tx = 0.0;
                    tz = 0.0;
                }
                default -> {
                    tx = fromNether ? x * 8.0 : x;
                    tz = fromNether ? z * 8.0 : z;
                }
            }
            // spreadplayers drops them on a safe surface (under the roof in the Nether, on the main island in the End)
            String under = dimension.equals("minecraft:the_nether") ? "under 120 " : "";
            run(server, String.format(Locale.ROOT, "execute in %s run spreadplayers %.1f %.1f 4 48 %sfalse %s",
                    dimension, tx, tz, under, id));
            if (e instanceof ServerPlayer sp) {
                String u = sp.getUUID().toString();
                run(server, "effect give " + u + " minecraft:fire_resistance 20 0 true");
                run(server, "effect give " + u + " minecraft:resistance 6 4 true");
                run(server, "effect give " + u + " minecraft:slow_falling 10 0 true");
            }
        }
        return self ? -1 : targets.size();
    }

    private static int overdrive(ServerPlayer player, MinecraftServer server) {
        UUID me = player.getUUID();
        String u = me.toString();
        run(server, "effect give " + u + " minecraft:speed 30 3 true");
        run(server, "effect give " + u + " minecraft:strength 30 3 true");
        run(server, "effect give " + u + " minecraft:haste 30 3 true");
        run(server, "effect give " + u + " minecraft:jump_boost 30 2 true");

        // three orange rings spiral inward as they rise
        double[] heights = {0.05, 1.1, 2.1};
        for (int i = 0; i < heights.length; i++) {
            final double y = heights[i];
            Scheduler.after(i * 130L, () -> WorldVfx.ring(server, me, "orange_stained_glass", 3.2, 0.7, y, 10));
        }
        WorldVfx.column(server, me, "orange_stained_glass", 1.4, 0.1, 0.6, 3.2, 8, 8);
        WorldVfx.sound(server, me, "minecraft:item.firecharge.use", 1.4f, 0.7f);
        return 1;
    }

    private static int omniscience(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        UUID me = player.getUUID();
        run(server, "effect give " + me + " minecraft:night_vision 60 0 true");
        int count = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(64.0))) {
            if (e == player) continue;
            runAs(server, e, "effect give @s minecraft:glowing 15 0 true");
            count++;
        }
        WorldVfx.ring(server, me, "lime_stained_glass", 1.0, 64.0, 0.05, 24);
        Scheduler.after(300, () -> WorldVfx.ring(server, me, "lime_stained_glass", 1.0, 48.0, 0.05, 20));
        WorldVfx.sound(server, me, "minecraft:block.beacon.power_select", 1.5f, 1.2f);
        return count;
    }

    private static int zeroG(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        UUID me = player.getUUID();
        int count = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(24.0))) {
            if (e == player || e instanceof Player) continue;
            runAs(server, e, "effect give @s minecraft:levitation 4 6 true");
            if (count < 10) {
                WorldVfx.column(server, e.getUUID(), "magenta_stained_glass", 1.0, 0.1, 0.5, 6.0, 10, 10);
            }
            count++;
        }
        WorldVfx.ring(server, me, "purple_stained_glass", 1.0, 24.0, 0.05, 14);
        WorldVfx.sound(server, me, "minecraft:block.respawn_anchor.charge", 1.4f, 0.6f);
        return count;
    }

    // ------------------------------------------------------------------ helpers

    /** Monsters near the player (never players, pets, villagers or animals). */
    private static List<LivingEntity> hostiles(ServerPlayer player, ServerLevel level, double radius) {
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius))) {
            if (e == player || e instanceof Player) continue;
            if (e.getType().getCategory() != MobCategory.MONSTER) continue;
            out.add(e);
        }
        return out;
    }

    /**
     * Marches along the player's look direction and returns {x, y(feet), z} of the last spot a player
     * could stand in before hitting something solid.
     */
    private static double[] rayEnd(ServerPlayer player, ServerLevel level, double maxDistance) {
        double yaw = Math.toRadians(player.getYRot());
        double pitch = Math.toRadians(player.getXRot());
        double dx = -Math.sin(yaw) * Math.cos(pitch);
        double dy = -Math.sin(pitch);
        double dz = Math.cos(yaw) * Math.cos(pitch);

        double ex = player.getX(), ey = player.getEyeY(), ez = player.getZ();
        double bx = player.getX(), by = player.getY(), bz = player.getZ();

        for (double s = 0.5; s <= maxDistance; s += 0.5) {
            double fx = ex + dx * s, fy = ey + dy * s, fz = ez + dz * s;
            double feetY = fy - 1.62;
            BlockPos feet = BlockPos.containing(fx, feetY, fz);
            BlockPos head = feet.above();
            if (blocked(level, feet) || blocked(level, head)) break;
            bx = fx;
            by = feetY;
            bz = fz;
        }
        return new double[]{bx, by, bz};
    }

    private static boolean blocked(ServerLevel level, BlockPos pos) {
        return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    private static String xyz(double x, double y, double z) {
        return String.format(Locale.ROOT, "%.2f %.2f %.2f", x, y, z);
    }

    /** Run a command as the server (full permissions, no chat spam). */
    private static void run(MinecraftServer server, String command) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
    }

    /** Run a command as an entity (@s = that entity). */
    private static void runAs(MinecraftServer server, LivingEntity e, String command) {
        run(server, "execute as " + e.getUUID() + " run " + command);
    }

    private static void runAt(MinecraftServer server, LivingEntity e, String command) {
        run(server, "execute as " + e.getUUID() + " at @s run " + command);
    }
}
